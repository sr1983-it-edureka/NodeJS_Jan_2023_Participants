
let firstName = "Sachin";

let lastName = "Tendulkar";

let fullName = firstName + " " + lastName;

console.log(fullName);

console.log("First name is " + firstName + ", Last name is " + lastName +
", Full name is " + fullName);

console.log('First name is ' + firstName + ', Last name is ' + lastName +
', Full name is ' + fullName);

// Backtick Operator
// " - Double Quotes
// ' - Single Quote

// Left Key of "1" Key
// ~ - Tilde Symbol [Shift  + Key]
// ` - Backtick Operator [Key]
console.log(`First name is ${firstName}, Last Name is ${lastName}, Full name is ${fullName} `);

