
console.log("beginning");

console.log("end");

// Synchronus Programming / Blocking Programming

