

export const testFunction = () => {
  console.log("Test function")
}

export const DB_CONNECTION_URL = "mongodb://localhost:27017";
