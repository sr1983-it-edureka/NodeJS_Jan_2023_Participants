
var orderId = 123;
var orderAmount = 999;
orderDate = new Date("18-Feb-2023");

const order = {
  orderId,
  orderAmount,
  orderDate
}

console.log(order);