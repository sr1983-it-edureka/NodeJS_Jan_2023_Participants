
const myStr1 = "product's price is 100";
console.log(myStr1);

const myStr2 = 'product "';
console.log(myStr2);

const myStr3 = "product \"";
console.log(myStr3);


const myStr4 = 'Hello \'world';
console.log(myStr4);