
const myCustomModule = require("./my-custom-module");

// const {myFunction, anotherFunction} = require("./my-custom-module");

// console.log(myCustomModule);

// myFunction();


myCustomModule.myFunction();
myCustomModule.anotherFunction();

console.log("Value of PI is " + myCustomModule.PI);
console.log("Edureka " + myCustomModule.EDUREKA);
