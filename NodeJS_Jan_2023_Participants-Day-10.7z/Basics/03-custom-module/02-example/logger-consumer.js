
// const logger = require("./logger");

const log = require("./logger");

// logger.log("Today is our 1st session in Mastering NodeJS");

log("Today is our 1st session in Mastering NodeJS");
