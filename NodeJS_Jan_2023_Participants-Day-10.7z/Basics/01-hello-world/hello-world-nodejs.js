
function displayHelloWorld() {

  console.log("Hello World from Node JS....");
}

displayHelloWorld();
