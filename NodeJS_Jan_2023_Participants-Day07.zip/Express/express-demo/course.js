
const course1 = {
  id: 1,
  name: "Full stack Web Developers Program",
  duration: "3 Months",
  rating : 4.3
}

const course2 = {
  id: 2,
  name: "AWS Certification Program",
  duration: "6 Months",
  rating : 4.5
}

const course3 = {
  id: 3,
  name: "MERN Stack",
  duration: "5 Months",
  rating : 4.1
}


const allCourses = [course1, course2, course3];

module.exports = {allCourses}

