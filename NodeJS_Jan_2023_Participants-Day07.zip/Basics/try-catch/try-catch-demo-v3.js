

console.log("Segment 1");




console.log("Segment 2");

const sessionObj = {
  id: 1,
  name: 'Node JS'
}

const sessionStr = JSON.stringify(sessionObj);
console.log(sessionStr);


const str = '{"id" 1,"name":"Node JS"}';

try{
  const sessionObj2 = JSON.parse(str);
  console.log(sessionObj2);

  console.log("Segment 3");

}catch(error){
  console.log("Error is " + error);
}






console.log("Segment 4");
