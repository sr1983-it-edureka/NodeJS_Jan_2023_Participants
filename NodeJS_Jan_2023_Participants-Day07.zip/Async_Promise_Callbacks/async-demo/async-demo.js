

console.log("beginning");

// External API [FB API]
// - 5 Seconds

// Line X

// Line Y


/// fetch("http://openweathermap.api") {

//}

// Caller
/*
const weatherData = fetch();

fetch( () => {

})

*/


// Asyn Function / Non-blocking function
setTimeout(() => {

  console.log("Fetching user data from database...");
}, 2000)


console.log("end");
