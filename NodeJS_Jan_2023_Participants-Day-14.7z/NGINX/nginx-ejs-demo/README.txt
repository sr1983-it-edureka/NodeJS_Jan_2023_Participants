Ubuntu

Git Installation

	sudo apt update
	sudo apt install git


NodeJS & NPM

	cd ~
	curl -sL https://deb.nodesource.com/setup_14.x -o nodesource_setup.sh
	nano nodesource_setup.sh
	sudo bash nodesource_setup.sh
	sudo apt install nodejs
	sudo apt install build-essential


NGINX

	sudo apt install nginx
	