//

// Declare an age
// Age - Number / Integer

// INT AGE = 30;

// Let -> Variable
let age = 30;
let name = "John";

// Const -> Constant
const ADDRESS_EDUREKA = "Bangalore, India";

console.log('Age is ' + age);
console.log("Name is " + name);

age = 35;
console.log('Age is ' + age);

console.log("Address is " + ADDRESS_EDUREKA);

ADDRESS_EDUREKA = "Mumbai, India";
