
var exportImportModule = require("./export-import");

exportImportModule.testFunction();

console.log(exportImportModule.DB_CONNECTION_URL);