
import chalk from "chalk";

let str1 = chalk.red("This will be writeten in red color");
console.log(str1);
