
Listing Courses
/courses/list

Inputs
  N/A

Ouputs
  A list of courses


#Get information about a Course

Inputs
  Course-Identifier

Output
  Course Details

Examples
  /courses/1
  /courses/123

# Adding a new Course


# Removing a Course

