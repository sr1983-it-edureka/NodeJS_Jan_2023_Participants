
const numbers = [3, 5, 7];

const newNumbers = [1 , 2, ...numbers];
//const newNumbers = [1 , 2, 3, 5, 7];

console.log(newNumbers);

const newNumbers2 = [100, 200, ...numbers, 300, 400];

console.log(newNumbers2);


