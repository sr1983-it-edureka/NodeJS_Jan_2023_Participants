
import {testFunction, DB_CONNECTION_URL} from "./export-import.mjs"

testFunction();

console.log(DB_CONNECTION_URL);