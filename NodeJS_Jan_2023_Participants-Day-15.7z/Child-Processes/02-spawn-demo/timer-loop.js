

const twoSeconds = 2 * 1000;

const interval = setInterval( () => {

  console.log(new Date());

}, twoSeconds);

// interval.cancel()