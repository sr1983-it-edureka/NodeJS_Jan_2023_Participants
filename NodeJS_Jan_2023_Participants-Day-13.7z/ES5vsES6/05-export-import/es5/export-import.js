
function testFunction(){

  console.log("Test function")
}

var DB_CONNECTION_URL = "mongodb://localhost:27017";

module.exports = {testFunction, DB_CONNECTION_URL}