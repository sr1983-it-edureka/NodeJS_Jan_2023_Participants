
const emp = 
{
  id: 1,
  name: 'Jack',
  projects: [ 'p1', 'p2' ],
  designation: 'Software Engineer',
  division: 'Engineering'
}

const projects = emp.projects;
const division = emp.division;

console.log("Projects -> " + projects);
console.log("Projects -> " + division);
