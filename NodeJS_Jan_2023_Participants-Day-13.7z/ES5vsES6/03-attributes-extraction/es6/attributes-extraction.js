const emp = 
{
  id: 1,
  name: 'Jack',
  projects: [ 'p1', 'p2' ],
  designation: 'Software Engineer',
  division: 'Engineering'
}


const {projects, division, a} = emp;

console.log("Projects -> " + projects);
console.log("Division -> " + division);
console.log("A -> " + a);
