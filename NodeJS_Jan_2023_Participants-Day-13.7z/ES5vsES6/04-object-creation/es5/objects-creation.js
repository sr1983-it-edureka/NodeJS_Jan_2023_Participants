
var orderId = 123;
var orderAmount = 999;
orderDate = new Date("18-Feb-2023");

const order = {
  orderId : orderId,
  orderAmount : orderAmount,
  orderDate: orderDate
}

console.log(order);