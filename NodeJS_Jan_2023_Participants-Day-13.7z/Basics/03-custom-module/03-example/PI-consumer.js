
const PI = require("./PI");

// PI();

console.log(PI);