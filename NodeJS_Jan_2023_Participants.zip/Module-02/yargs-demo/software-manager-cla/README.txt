software-install --name=Chrome --version=109.0 --repository=http://mysoftwares.com

software-uninstall --name=notepad --version=1.0

software-list

software-search --name=Ch


add 10 20
add --number1=10 -number2=20
