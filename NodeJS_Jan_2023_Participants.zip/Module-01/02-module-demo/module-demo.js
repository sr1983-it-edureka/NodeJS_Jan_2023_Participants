
// console.log(module);

console.log(module.path);

console.log(module.filename);