
function demo(name, id){

  console.log(name)
  console.log(id);
}

demo("Hello", 123);