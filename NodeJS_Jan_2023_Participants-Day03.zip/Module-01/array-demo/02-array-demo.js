
const popularProgrammingLanguages = new Array();

popularProgrammingLanguages.push("Python");
popularProgrammingLanguages.push("Java Script");
popularProgrammingLanguages.push("Java");

console.log(popularProgrammingLanguages);
